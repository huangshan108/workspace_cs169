# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Rottenpotatoes::Application.config.secret_token = '106894f8e0074f83ae8d28df623c2e6937b3bd0e3fd7c543a23f8b576263a0d3829614c2fcbc9dcb5ef11424f1334246b542779b15bb4ac96693b0967bf4d48d'
